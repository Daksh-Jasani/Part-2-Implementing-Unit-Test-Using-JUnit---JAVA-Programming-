# Part-2-Implementing-Unit-Test-Using-JUnit---JAVA-Programming-

Content of the Repository

This repository consists of four Java File that teach us about JUnit Testing.

File 1 - JunitTesting.java
File 2 - dividetesttrue.java
File 3 - dividetestfalse.java
File 4 - CombinedTest.java

Open Eclipse and import "Part-2-Implementing-Unit-Test-Using-JUnit---JAVA-Programming- by :

1st Step - File > Import > General > Projects From Folder or Archive > Next, then select "art-2-Implementing-               Unit-Test-Using-JUnit---JAVA-Programming-" project and import it.

2nd Step - Click on Run or Green Button with Play Symbol.

After execution of "dividetesttrue.java" you will see that a green bar on the right side which implies that the test has been passed.

After execution of "dividetestfalse.java" you will see that a red bar on the right side which implies that the test has been passed.

After execution of "CombinedTest.java" you will see that a green bar on the right side which implies that the test has been passed.

JunitTesting. java is a file in which there are fucntion written that are being executed in the other three files.